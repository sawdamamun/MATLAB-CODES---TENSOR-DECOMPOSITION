
function ObjFcn = makeObjFcnImage(XTrain,XValidation,YValidation)

ObjFcn = @valErrorFun;
 function [valError,cons,fileName] = valErrorFun(optimVars)

        imageSize = [480 640 3];
        numClasses = 5;
        numF = round(8/sqrt(optimVars.SectionDepth));
        layers = [
            imageInputLayer(imageSize)
            convBlock(3,numF,optimVars.SectionDepth)
            maxPooling2dLayer(2,'Stride',1,'Padding','same')
            convBlock(3,2*numF,optimVars.SectionDepth)
            maxPooling2dLayer(2,'Stride',1,'Padding','same')
            convBlock(3,4*numF,optimVars.SectionDepth)
            averagePooling2dLayer(4)
            fullyConnectedLayer(32)
            fullyConnectedLayer(numClasses)
            softmaxLayer
            classificationLayer];
        
%% Parameters in CNNs 
         
        miniBatchSize = 20;
        validationFrequency = 5;
        options = trainingOptions('adam', ...
            'ExecutionEnvironment','gpu',...
            'InitialLearnRate',optimVars.InitialLearnRate, ...
            'MaxEpochs',20, ...
            'LearnRateSchedule','piecewise', ...
            'LearnRateDropPeriod',15, ...
            'LearnRateDropFactor',0.5, ...
            'MiniBatchSize',miniBatchSize, ...
            'L2Regularization',optimVars.L2Regularization, ...
            'Shuffle','every-epoch', ...
            'Verbose',false, ...
            'Plots','training-progress', ...
            'ValidationData',{XValidation,YValidation}, ...
            'ValidationFrequency',validationFrequency);  

   trainedNet = trainNetwork(XTrain,layers,options);
   YPredicted = classify(trainedNet,XValidation);
   valError = 1 - mean(YPredicted == YValidation);
   fileName = num2str(valError) + ".mat";
        save(fileName,'trainedNet','valError','options')
        cons = [];
        
    end
end

function layers = convBlock(filterSize,numFilters,numConvLayers)
layers = [
    convolution2dLayer(filterSize,numFilters,'Padding','same')
    batchNormalizationLayer
    reluLayer];
layers = repmat(layers,numConvLayers,1);
end        
        