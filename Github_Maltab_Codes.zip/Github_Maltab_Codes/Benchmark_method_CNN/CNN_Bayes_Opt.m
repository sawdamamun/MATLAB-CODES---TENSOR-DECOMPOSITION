
clc;clear;close all;

warning('off')
d1 = ('D:\Fabric Classification MPCA\Work Procedures\Benchmark_method_images\Phase_03\CNN_training_images\Run_1');
imds = imageDatastore(d1,'FileExtensions','.jpg','ReadFcn',@importdata,'IncludeSubfolders',true,'LabelSource','foldernames');

%%
T = imds;
[XTrain, XValidation,imdsTest]=splitEachLabel(T,0.8,0.10, 'randomize');
optimVars = [
    optimizableVariable('SectionDepth',[1 3],'Type','integer')
    optimizableVariable('InitialLearnRate',[1e-4 1e-2],'Transform','log')
    optimizableVariable('L2Regularization',[1e-10 1e-2],'Transform','log')];

%% for training labels
labelCount_tr = countEachLabel(XTrain);
labels_tr=XTrain.Labels;
YTrain = XTrain.Labels;

%% for validation labels
labelCount_val = countEachLabel(XValidation);
labels_val=XValidation.Labels;
YValidation = XValidation.Labels;

%% Bayesian optimization 
ObjFcn = makeObjFcnImage(XTrain,XValidation,YValidation);
BayesObject = bayesopt(ObjFcn,optimVars, ...
    'MaxObjectiveEvaluations',10, ...
    'IsObjectiveDeterministic',false, ...
    'UseParallel',false);




