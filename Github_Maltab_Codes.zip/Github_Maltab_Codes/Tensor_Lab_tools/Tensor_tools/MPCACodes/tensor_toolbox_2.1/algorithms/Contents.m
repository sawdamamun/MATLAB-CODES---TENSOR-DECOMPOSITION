% Algorithms for the Tensor Toolbox
%
% Files
%   parafac_als - Compute a PARAFAC decomposition of any type of tensor.
%   tucker_als  - Higher-order orthogonal iteration.
