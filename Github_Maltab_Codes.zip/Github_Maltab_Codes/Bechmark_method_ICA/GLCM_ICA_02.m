%% GLCM + ICA + SVM

% clc;clear;close all;
% 
% for k = 1 : 5
%     k
% imageDir = (['D:\Fabric Classification MPCA\Work Procedures\ICA_Dataset\Twill\Set_' int2str(k)]); 
% imageFiles = dir(fullfile(imageDir, '*.jpg')); 
% numImages = numel(imageFiles);
% features = [];
% for i = 1:numImages
%     image = imread(fullfile(imageDir, imageFiles(i).name));
%     grayImage = rgb2gray(image);
%     LB  = extractLBPFeatures(grayImage, 'Upright',false); %% LBP features
% offsets = [0 1; -1 1; -1 0; -1 -1]; 
% numLevels = 8;
% symmetricGLCM = true; 
% grayLimits = []; 
% glcm = graycomatrix(LB, 'Offset', offsets, 'NumLevels', numLevels, ...
%     'Symmetric', symmetricGLCM, 'GrayLimits', grayLimits); 
% grayImage_A = imresize(glcm , [60, 60]);
% imageVector = grayImage_A(:);
% features = [features, imageVector];
% end
% X = double(features);
% Zfica = fastICA(X',50); %% match number of observations with MPCA method
% xlswrite(['twill_set_' int2str(k) '.xlsx'],Zfica(:,1:999)); %% features selection
% 
% end


%% Data spliting for training and testing
% clc;clear;close all;
% 
% A_1 = xlsread('interlock_set_5.xlsx');
% A_2 = xlsread('jacquard_set_5.xlsx');
% A_3 = xlsread('plain_set_5.xlsx');
% A_4 = xlsread('rib_set_5.xlsx');
% A_5 = xlsread('twill_set_5.xlsx');
% 
% numRows_1 = size(A_1, 1);
% numRows_2 = size(A_2, 1);
% numRows_3 = size(A_3, 1);
% 
% randomIndices_1 = randperm(numRows_1);
% randomIndices_2 = randperm(numRows_2);
% randomIndices_3 = randperm(numRows_3);
% 
% splitPoint_1 = round(numRows_1*0.6); % Split the matrix in half, adjust as needed
% splitPoint_2 = round(numRows_2*0.2);
% splitPoint_3 = round(numRows_3*0.2);
% 
% A_1_tr_face = A_1(randomIndices_1(1:splitPoint_1), :);
% A_1_te_face = A_1(randomIndices_2(1:splitPoint_2), :);
% A_1_val_face = A_1(randomIndices_3(1:splitPoint_3),:);
% 
% A_2_tr_face = A_2(randomIndices_1(1:splitPoint_1), :);
% A_2_te_face = A_2(randomIndices_2(1:splitPoint_2), :);
% A_2_val_face=  A_2(randomIndices_3(1:splitPoint_3),:);
% 
% 
% A_3_tr_face = A_3(randomIndices_1(1:splitPoint_1), :);
% A_3_te_face = A_3(randomIndices_2(1:splitPoint_2), :);
% A_3_val_face = A_3(randomIndices_3(1:splitPoint_3), :);
% 
% A_4_tr_face = A_4(randomIndices_1(1:splitPoint_1), :);
% A_4_te_face = A_4(randomIndices_2(1:splitPoint_2), :);
% A_4_val_face = A_4(randomIndices_3(1:splitPoint_3), :);
% 
% A_5_tr_face = A_5(randomIndices_1(1:splitPoint_1), :);
% A_5_te_face = A_5(randomIndices_2(1:splitPoint_2), :);
% A_5_val_face = A_5(randomIndices_3(1:splitPoint_3), :);
% 
% X_tr_set_5 = [A_1_tr_face; A_2_tr_face ;A_3_tr_face; A_4_tr_face; A_5_tr_face];
% X_te_set_5 = [A_1_te_face; A_2_te_face ;A_3_te_face; A_4_te_face; A_5_te_face];
% X_val_set_5 = [A_1_val_face; A_2_val_face ;A_3_val_face; A_4_val_face; A_5_val_face];
% 
% 
% save('X_tr_set_5.mat', 'X_tr_set_5');
% save('X_te_set_5.mat', 'X_te_set_5');
% save('X_val_set_5.mat', 'X_val_set_5');

%% SVM model training, validation and test

% clc;clear;close all;
% 
% load ("X_tr_set_5.mat");
% load("X_te_set_5.mat");
% load("X_val_set_5.mat");
% 
% u_1 = repelem(1,30)';
% u_2 = repelem(2,30)';
% u_3 = repelem(3,30)';
% u_4 = repelem(4,30)';
% u_5 = repelem(5,30)';
% 
% Xtrain = X_tr_set_5;
% Ytrain = categorical([u_1;u_2;u_3;u_4;u_5]);
% 
% v_1 = repelem(1,10)';
% v_2 = repelem(2,10)';
% v_3 = repelem(3,10)';
% v_4 = repelem(4,10)';
% v_5 = repelem(5,10)';
% 
% Xtest = X_te_set_5;
% Ytest = categorical([v_1;v_2;v_3;v_4;v_5]);
% Xval = X_val_set_5;
% 
% 
% %%
% tTree = templateTree('surrogate','on');
% tEnsemble = templateEnsemble('GentleBoost',100,tTree);
% options = statset('UseParallel',true);
% 
% trained_Model = fitcecoc(Xtrain,Ytrain,'Coding','onevsall','Learners',tEnsemble,...
%                 'Prior','uniform','NumBins',500,'Options',options);
% 
% %%
% 
% predictedLabels = predict(trained_Model, Xval);
% accuracy_val = sum(predictedLabels == Ytest) / numel(Ytest);
% 
% %%
% tic
% predictedLabels = predict(trained_Model, Xtest);
% accuracy_test = sum(predictedLabels == Ytest) / numel(Ytest);
% disp(['Classification accuracy: ' num2str(accuracy_test)]);
% CM_05 = confusionmat(Ytest,predictedLabels);
% time = toc;
% save ('CM_05.mat', 'CM_05')

%% Confusion matrix: precision & recall calculaiton

% clc;clear;close all;
% 
% load CM_05.mat
% cm = CM_05;
% cmt = cm';
% Diagonal = diag(cmt);
% sum_of_rows = sum(cmt,2);
% precision = Diagonal ./ sum_of_rows;
% Overall_precision = mean(precision);
% sum_of_rows = sum(cmt,1);
% recall = Diagonal ./ sum_of_rows';
% Overall_recall = mean(recall);
% F_score = 2*(Overall_precision*Overall_recall)/(Overall_precision+Overall_recall);





