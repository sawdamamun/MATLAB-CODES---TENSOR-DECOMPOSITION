%% MPCA projected features

% clc;clear;close all;
% 
% for k = 1: 50
% k
% imageDir = (['D:\Fabric Classification MPCA\Work Procedures\Data_set_MPCA_01\MPCA_project\Set_1\Run_' int2str(k)]);
% imageFiles = dir(fullfile(imageDir, '*.jpg')); 
% numImages = numel(imageFiles);
% MPCA_train_01 = [];
% 
% for i = 1:numImages
%     image = imread(fullfile(imageDir, imageFiles(i).name));
%     grayImage = rgb2gray(image);
% 
% LB  = extractLBPFeatures(grayImage, 'Upright',false); %% LBP features
% 
% offsets = [0 1; -1 1; -1 0; -1 -1];
% numLevels = 8; 
% symmetricGLCM = true; 
% grayLimits = []; 
% glcm = graycomatrix(LB, 'Offset', offsets, 'NumLevels', numLevels, ...
%     'Symmetric', symmetricGLCM, 'GrayLimits', grayLimits); %% properties = {'Contrast', 'Correlation', 'Energy', 'Homogeneity'};
% grayImage_A = imresize(glcm , [60, 60]); %% re-size image
% imageVector = grayImage_A(:);
% MPCA_train_01 = [MPCA_train_01, imageVector];
% end
% MPCA_Train_01{k,1} = double(MPCA_train_01); %% MPCA projected features 
% end


%% MPCA feature extraction

% clc;clear;close all;
% 
% for k = 1: 50
% k
% imageDir = (['D:\Fabric Classification MPCA\Work Procedures\Data_set_MPCA_02\MPCA_feature\Set_5\Twill\Run_' int2str(k)]);
% imageFiles = dir(fullfile(imageDir, '*.jpg')); 
% numImages = numel(imageFiles);
% MPCA_feature_twill_05 = [];
% for i = 1:numImages
%     image = imread(fullfile(imageDir, imageFiles(i).name));
%     grayImage = rgb2gray(image);
% LB  = extractLBPFeatures(grayImage, 'Upright',false); %% LBP features
% offsets = [0 1; -1 1; -1 0; -1 -1];
% numLevels = 8; 
% symmetricGLCM = true; 
% grayLimits = []; 
% glcm = graycomatrix(LB, 'Offset', offsets, 'NumLevels', numLevels, ...
%     'Symmetric', symmetricGLCM, 'GrayLimits', grayLimits); %% properties = {'Contrast', 'Correlation', 'Energy', 'Homogeneity'};
% grayImage_A = imresize(glcm , [60, 60]);%% re-size image
% imageVector = grayImage_A(:);
% MPCA_feature_twill_05 = [MPCA_feature_twill_05, imageVector];
% end
% MPCA_Twill_05{k,1} = double(MPCA_feature_twill_05); %%  MPCA feature extraction
% end


%% MPCA codes for tensor decomposition

% clc;clear;close all;
% 
% load MPCA_Train_01.mat
% 
% load MPCA_Interlock_05.mat
% load MPCA_Jacquard_05.mat
% load MPCA_Plain_05.mat
% load MPCA_Rib_05.mat
% load MPCA_Twill_05.mat
% 
% X_project =  MPCA_Train_01;
% X_feature = [MPCA_Interlock_05;MPCA_Jacquard_05;MPCA_Plain_05;MPCA_Rib_05;MPCA_Twill_05];
% 
% 
% XTrain = zeros([14400, 20, 50], 'double');
% 
% for i = 1:length(X_project)
% XTrain(:, :, i) = X_project{i};
% end
% 
% XTest = zeros([14400, 20, 250], 'double');
% 
% for i = 1:length(X_feature)
% XTest(:, :, i) = X_feature{i};
% end
% 
% %%add path of MPCA toolboxes
% 
% addpath('D:\Fabric Classification MPCA\Work Procedures\Tensor_tools\MPCACodes')
% addpath('D:\Fabric Classification MPCA\Work Procedures\Tensor_tools\tensor_toolbox-master')
% addpath('D:\Fabric Classification MPCA\Work Procedures\Tensor_tools\cp3_DCPD.m')
% addpath('D:\Fabric Classification MPCA\Work Procedures\Tensor_tools\MPCACodes\tensor_toolbox_2.1')
% 
% %%training MPCA
% 
% [tUs, odrIdx, TXmean, ~]  = MPCA(XTrain,-1,95,1);
% N=ndims(XTrain)-1;
% Is=size(XTrain);
% numSpl=Is(3);
% fea2Dctr=XTrain-repmat(TXmean,[ones(1,N), numSpl]);%Centering
% newfea=ttm(tensor(fea2Dctr),tUs,1:N);%MPCA projection
% 
% %Residual calculation trial newly added %%
% for n=1:2
%     tUs_trans{n,1}=tUs{n,1}'; % transpose tUs
% end
% 
% %%testing MPCA
% tic
% Iste=size(XTest);
% numSplte=Iste(3);
% fea2Dctr_te=XTest-repmat(TXmean,[ones(1,N), numSplte]);%Centering
% newfea_te=ttm(tensor(fea2Dctr_te),tUs,1:N);%MPCA projection
% 
% %%Residual calculation trial newly added 
% Error_te=tensor(fea2Dctr_te)-ttm(newfea_te,tUs_trans,1:2);
% ErrorDim_te=size(Error_te,1)*size(Error_te,2);
% Error_test_vector=reshape(Error_te.data,ErrorDim_te,numSplte)';%% Note: Transposed
% for n=1:numSplte
%     Q_te(n)=norm(Error_test_vector(n,:));
% end
% 
% %%Vectorization of the tensorial feature
% newfeaDim_te=size(newfea_te,1)*size(newfea_te,2);
% P=length(odrIdx);
% newfea_te=reshape(newfea_te.data,newfeaDim_te,numSplte)';%Note: Transposed
% selfea_te=newfea_te(:,odrIdx(1:floor(P)));%Select the first "P" sorted features
% Chat=cov(selfea_te);
% F2_te=diag(selfea_te*inv(Chat)*selfea_te');
% 
% %%extracted testing features
% X_selfea_05=selfea_te;
% feature_time = toc;
% save ('X_selfea_05.mat', 'X_selfea_05')

%% MPCA extracted features split for model training, vladation and test

% clc;clear;close all;
% 
% load X_selfea_05.mat
% 
% ALL = X_selfea_05;
% 
% A_1 = ALL(1:50,:);
% A_2 = ALL(51:100,:);
% A_3 = ALL(101:150,:);
% A_4= ALL(151:200,:);
% A_5 = ALL(201:250,:);
% 
% numRows = size(A_1, 1);
% randomIndices = randperm(numRows);
% splitPoint_1 = round(numRows*0.6); % Split the matrix in half, adjust as needed
% splitPoint_2 = round(numRows*0.2);
% splitPoint_3 = round(numRows*0.2);
% 
% A_1_tr_face = A_1(randomIndices(1:splitPoint_1), :);
% A_1_te_face = A_1(randomIndices(1:splitPoint_2), :);
% A_1_val_face = A_1(randomIndices(1:splitPoint_3),:);
% 
% A_2_tr_face = A_2(randomIndices(1:splitPoint_1), :);
% A_2_te_face = A_2(randomIndices(1:splitPoint_2), :);
% A_2_val_face=  A_2(randomIndices(1:splitPoint_3),:);
% 
% 
% A_3_tr_face = A_3(randomIndices(1:splitPoint_1), :);
% A_3_te_face = A_3(randomIndices(1:splitPoint_2), :);
% A_3_val_face = A_3(randomIndices(1:splitPoint_3), :);
% 
% A_4_tr_face = A_4(randomIndices(1:splitPoint_1), :);
% A_4_te_face = A_4(randomIndices(1:splitPoint_2), :);
% A_4_val_face = A_4(randomIndices(1:splitPoint_3), :);
% 
% A_5_tr_face = A_5(randomIndices(1:splitPoint_1), :);
% A_5_te_face = A_5(randomIndices(1:splitPoint_2), :);
% A_5_val_face = A_5(randomIndices(1:splitPoint_3), :);
% 
% X_Tr_05_01 = [A_1_tr_face; A_2_tr_face ;A_3_tr_face; A_4_tr_face; A_5_tr_face];
% X_Te_05_01 = [A_1_te_face; A_2_te_face ;A_3_te_face; A_4_te_face; A_5_te_face];
% X_Val_05_01 = [A_1_val_face; A_2_val_face ;A_3_val_face; A_4_val_face; A_5_val_face];
% 
% save ('X_Tr_05_01.mat', 'X_Tr_05_01')
% save ('X_Te_05_01.mat', 'X_Te_05_01')
% save ('X_Val_05_01.mat','X_Val_05_01')


%% SVM SVM model training, validation and test

% clc;clear;close all;
% 
% load X_Tr_05_01.mat
% load X_Te_05_01.mat
% load X_Val_05_01.mat
% 
% P1 = xlsread('X_train_label_02.xlsx');
% P3 = xlsread('X_test_label_02.xlsx');
% Xtrain = X_Tr_05_01;
% Ytrain = categorical(P1);
% Xtest = X_Te_05_01;
% Ytest = categorical(P3);
% Xval = X_Val_05_01;
% 
% %%SVM model training
% tTree = templateTree('surrogate','on');
% tEnsemble = templateEnsemble('GentleBoost',100, tTree);
% options = statset('UseParallel',true);
% trained_Model = fitcecoc(Xtrain,Ytrain,'Coding','onevsall','Learners',tEnsemble,...
%                 'Prior','uniform','NumBins',500,'Options',options);
% 
% %%trained model validation
% 
% predictedLabels_val = predict(trained_Model, Xval);
% accuracy_val = sum(predictedLabels_val == Ytest) / numel(Ytest);
% 
% %%trained model testing
% tic;
% predictedLabels = predict(trained_Model, Xtest);
% accuracy_test = sum(predictedLabels == Ytest) / numel(Ytest);
% disp(['Classification accuracy: ' num2str(accuracy_test)]);
% CM_05_01 = confusionmat(Ytest,predictedLabels);
% time_te = toc;
% save ('CM_05_01.mat', 'CM_05_01') %% save confusion matrix


%% Confusion matrix: precision & recall calculaiton

% clc;clear;close all;
% 
% load CM_05_01.mat
% cm = CM_05_01;
% cmt = cm';
% Diagonal = diag(cmt);
% sum_of_rows = sum(cmt,2);
% precision = Diagonal ./ sum_of_rows;
% Overall_precision = mean(precision);
% sum_of_rows = sum(cmt,1);
% recall = Diagonal ./ sum_of_rows';
% Overall_recall = mean(recall);
% F_score = 2*(Overall_precision*Overall_recall)/(Overall_precision+Overall_recall);

